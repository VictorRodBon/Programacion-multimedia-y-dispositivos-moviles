package com.example.myapplication

import androidx.compose.foundation.Image
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.MyApplicationTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent{
            MyApplicationTheme() { // Usaremos el tema
                MyComponent()
            }
        }
    }
}

@Composable
fun MyComponent(){ //Se usa el fondo del tema en la fila
    Row(Modifier.background(MaterialTheme.colorScheme.background)){ // Usar fondo definido en el tema
        MyImage()
        MyTexts()
    }
}

@Composable
fun MyImage(){
    Image(
        painterResource(R.drawable.ic_launcher_foreground),
        contentDescription = "Icono Android",
        modifier = Modifier
            .clip(CircleShape) // Recortar redondo (importante que este antes que el fondo)
            .background(MaterialTheme.colorScheme.secondary) // Fondo de la imagen
            .size(60.dp) // Tamaño de la imagen
    )
}

@Composable
fun MyTexts() {
    Column() {
        MyText("Hola Mundo", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge)
        MyText("Ready?", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun MyText(text: String, color: Color, style: TextStyle){ //Acepta parámetro color y estilo
    Text(text, color = color, style = style) //Los aplica
}

@Preview
@Composable
fun PreviewComposable(){
    MyApplicationTheme() { //En el preview también se aplicará el tema
        MyComponent()
    }
}


